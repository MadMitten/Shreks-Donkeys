/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakes.ladders;

import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author k00225361
 */
public class PlayGame {

    Grid g1 = new Grid();

    Players player1 = new Players(); //Instance of the object.
    Players player2 = new Players();
    boolean isPlayer1;
    boolean winner = false;
    boolean inBounds;

    public void playGame() throws FileNotFoundException //Prints grid then lets players roll their dice while no one has fun.
    {
        g1.viewGrid(g1.empty, g1.shrek, g1.donkey);

        while (winner != true) {
            player1.movePlayer(player1.playerRoll());
            player2.movePlayer(player2.playerRoll());

            if (inBound(player1.position)) {
                if (inBound(player1.position) == true) {
                    System.out.println(player1.name + " wins");
                    System.out.println("Counter: " + player1.counter);
                    winner = true;
                }
            } else if (inBound(player2.position)) {
                if (inBound(player2.position) == true) {
                    System.out.println(player1.name + " wins");
                    System.out.println("Counter: " + player1.counter);
                    winner = true;
                }
            } //If the player has not passed the end of the grid then roll the dice.
            else {

                checkSpace(player1.position, true);
                checkSpace(player2.position, false);

            }//End else
        }//End of while.

        if (winner == true) {
            Scanner sc = new Scanner(System.in);
            WinnerRevealed(sc);
        }
    }//End of playGame.

    public void checkSpace(int position, boolean isPlayer1) //Checks if a player wins or if they land on one of the items.
    {
        Random rand = new Random();
        char d = g1.gridSize[position].charAt(0);
        int x = rand.nextInt(6) + 1;

        switch (d) {
            case 'S':
                if (isPlayer1 = true) {
                    x = x * 2;
                    player1.position = player1.position + x;
                    player1.score += player1.score + (player1.playerDice * 2);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player1.name + " appoarch shrek, He screams "+ "Get outta my swamp, You runs past him "+" You've moved an extra " + x + " space.");
                    System.out.println(player1.name + " position: " + player1.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                } else {
                    x = x * 2;
                    player2.position = player2.position + x;
                    player2.score = player2.score + (player2.playerDice * 2);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player2.name + " appoarch shrek, He screams "+ "Get outta my swamp, You runs past him "+" You've moved an extra " + x + " space.");
                    System.out.println(player2.name + " position: " + player2.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                }
                break;
            case 'D':
                if (isPlayer1 = true) {
                    x = x * 2;
                    player1.position = player1.position - x;
                    player1.score = player1.score - (player1.playerDice * 2);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player1.name + " hit donkey, He replies "+ "You cut me, You cut me real deep. He kicks you." + " You've been pushed back " + x + " space.");
                    System.out.println(player1.name + " position: " + player1.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                } else {
                    x = x * 2;
                    player2.position = player2.position - x;
                    player2.score = player2.score - (player2.playerDice * 2);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player2.name + " hit donkey, He replies "+ "You cut me, You cut me real deep. He kicks you." + " You've been pushed back " + x + " space.");
                    System.out.println(player2.name + " position: " + player2.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                }
                break;
            case 'F':
                if (isPlayer1 == true) {
                    player1.position = 105;
                    player1.score = player1.score + (player1.playerDice * 5);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player1.name + " found the princess, She replies " + "I am, awaiting a knight so bold as to rescue me." + "You Win");
                    System.out.println(player1.name + " position: " + player1.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                    
                } else {
                    player2.score = player2.score + (player2.playerDice * 5);
                    player2.position = 105;
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player2.name + " found the princess, She replies " + "I am, awaiting a knight so bold as to rescue me." + "You Win");
                    System.out.println(player2.name + " position: " + player2.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                    
                }
                break;
            case 'P':
                if (isPlayer1 = true) {
                    player1.score = player1.score - (player1.playerDice * 5);
                    player1.position = 0;
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player1.name + " engages Puss in Boot, He replies " + "Fight me if you dare."+" You lost.");
                    System.out.println(player1.name +" position: " + player1.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                } else {
                    player2.position = 0;
                    player2.score = player2.score - (player2.playerDice * 5);
                    System.out.println("________________________________________________________________________________________________________________________________________");
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println(player2.name + " engages Puss in Boot, he replies " + "Fight me if you dare."+" You lost.");
                    System.out.println(player2.name + " position: " + player2.position);
                    System.out.println("----------------------------------------------------------------------------------------------------------------------------------------");
                    System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
                    System.out.println("\n");
                }
                break;
            default:
        }//End of class.
    }//End of checkSpace method.

    private boolean inBound(int position) {
        if (position > g1.gridSize.length) {
            return true;
        } else {
            return false;
        }
    }//End of inBounds method.
    
    public enum Decision{
        y,yes,n,no;
        
        public static Decision getDecision(String decision){
            for(Decision d : values()){
                if(d.name().equalsIgnoreCase(decision)){
                    return d;
                }
            }//end of for
            return null;
        }//end of getDecision
    }//end of enum
    
    private void WinnerRevealed(Scanner sc) throws FileNotFoundException {
        Analytics a = new Analytics();
        System.out.println("____________________________________________________________________");
        System.out.println("--------------------------------------------------------------------");
        System.out.println("press a number to continue ");
        int i = Integer.parseInt(sc.nextLine()); //to help avoid doing next int the next line
        System.out.println("Do you want to see the Stats of the the game? 'y'/'yes' or 'n'/'no'");
        System.out.print("Input: ");
        Decision decision = Decision.getDecision(sc.nextLine());
        System.out.println("--------------------------------------------------------------------");
        System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        
        
        while(decision == null){
            System.out.println("____________________________________________________________________");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Invalid Entry");
            System.out.println("Do you want to see the Stats of the the game? 'y'/'yes' or 'n'/'no' ");
            System.out.print("Input: ");
            decision = Decision.getDecision(sc.nextLine());
            System.out.println("--------------------------------------------------------------------");
            System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");

        }//end of while
        
        switch(decision){
            case y:
            case yes:
                System.out.println("___________________________________________________________________");
                System.out.println("-------------------------------------------------------------------");
                System.out.println("You have have choosen 'y'/'yes' press 1 to continue");
                System.out.print("Input: ");
                int x = sc.nextInt();
                System.out.println("-------------------------------------------------------------------");
                System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");


                if(x == 1){
                    System.out.println("____________________________________________________________");
                    System.out.println("------------------------------------------------------------");
                    System.out.println("----------------------Welcome to Stats----------------------");
                    a.Stats();
                }//end of if

            break;

            case n:
            case no:
                 System.out.println("You have have choosen 'n'/'no' press 1 to continue");
                 int z = sc.nextInt();
            break;
            default:
                System.out.println("Invalid Entry");
            break;

        }//end of switch

    }//Winner Revealed
        
}//End of class.
