/*
 * Create player object that tracks player name and has two method.
 * playerName asks for the users name and strores it in name.
 *  playerRoll rolls a random number and 
 */
package snakes.ladders;

import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author k00225361
 */
public class Players {

    String name;
    Scanner scan = new Scanner(System.in);
    int playerDice;
    int rollChoice;
    int position;
    Random rand = new Random();
    int counter;
    int score;
    int numberofRolls;
    
    Grid g1 = new Grid();
    
    public Players() {
        playerName();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setScore(int score){
        this.score = score;
    }
    
    public int getScore(){
        return score;
    }

    public Scanner getScan() {
        return scan;
    }

    public void setScan(Scanner scan) {
        this.scan = scan;
    }

    public int getPlayerDice() {
        return playerDice;
    }

    public void setPlayerDice(int playerDice) {
        this.playerDice = playerDice;
    }

    public int getRollChoice() {
        return rollChoice;
    }

    public void setRollChoice(int rollChoice) {
        this.rollChoice = rollChoice;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public Random getRand() {
        return rand;
    }

    public void setRand(Random rand) {
        this.rand = rand;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public int getNumberofRolls() {
        return numberofRolls;
    }

    public void setNumberofRolls(int numberofRolls) {
        this.numberofRolls = numberofRolls;
    }

    public Grid getG1() {
        return g1;
    }

    public void setG1(Grid g1) {
        this.g1 = g1;
    }

    public String playerName() {
        System.out.println("___________________________________");
        System.out.println("-----------------------------------");
        System.out.println("Enter name for Player: ");
        System.out.print("Input: ");
        name = scan.nextLine();
        System.out.println("-----------------------------------");
        System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        return name;
    }

    public int playerRoll() {
        System.out.println("___________________________________");
        System.out.println("-----------------------------------");
        System.out.println(name + " press 1 to roll your dice");
        System.out.print("Input: ");
        rollChoice = scan.nextInt();
        playerDice = rand.nextInt(100) + 1;
        System.out.println(getName() + " Rolled: " + playerDice);
        counter++;
        score++;
        numberofRolls++;
        return playerDice;
    }

    public int movePlayer(int playerDice) {
        position = position + playerDice;
        System.out.println(getName() + " position: " + position);
        System.out.println("-----------------------------------");
        System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        return position;
    }

    
    

}//End of class.
