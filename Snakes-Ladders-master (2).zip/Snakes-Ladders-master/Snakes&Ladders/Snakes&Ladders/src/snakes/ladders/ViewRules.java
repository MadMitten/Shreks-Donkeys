/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakes.ladders;

/**
 *
 * @author k00225361
 */
public class ViewRules {
    
    public void viewRules()
    {
        System.out.println("      Rules");
        System.out.println("------------------");
        System.out.println("-   You roll a six sided dice.");
        System.out.println("-   If land on a snake you will fall down the board depending on the length of said snake");
        System.out.println("-   Ladders bring you up the board depending length of said ladder");
        System.out.println("-   First player to the top wins.");
        System.out.println("\n");
    }
    
}
