/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shrek.donkeys;

/**
 *
 * @author k00225361
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.*;

/**
 *
 * @author k00225361
 */
//Inheritance
public class Analytics extends PlayGame {
    
    PlayGame p = new PlayGame();

    public Players getPlayer1() {
        return p.player1;
    }

    public void setPlayer1(Players player1) {
        this.p.player1 = player1;
    }

    public Players getPlayer2() {
        return p.player2;
    }

    public void setPlayer2(Players player2) {
        this.p.player2 = player2;
    }
    
    public void setPlayer1Score(Players player1)
    {
         this.player1.score = player1.score;
    }
     
    void Stats() throws FileNotFoundException {
        System.out.println("------------------------------------------------------------");
        System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");

        String Player1Name = p.player1.name;
        String Player2Name = p.player2.name;
        int Player1Score = p.player1.score;
        int Player2Score = p.player2.score;
        int Player1DiceRolls = p.player1.numberofRolls;
        int Player2DiceRolls = p.player2.numberofRolls;
        int Rounds = (p.player1.counter + p.player2.counter) / 2;
        String winner = null;

        if (Player1Score > Player2Score) {
            winner = "Player 1 - " + Player1Name + " is the Winner interms of Score";
        } else if (Player1Score < Player2Score) {
            winner = "Player 2 - " + Player2Name + " is the Winner interms of Score";
        }

        String outputfileName = "Stats.txt";
        String inputText;

        PrintWriter out = new PrintWriter(outputfileName);

        inputText
                = "------------------------------------------------------------" + "\n"
                + "- Player_One_Name: " + Player1Name + "\n"
                + "- Player_One_Score: " + Player1Score + "\n"
                + "- Player_One_Number_of_Dice_Rolls: " + Player1DiceRolls + "\n"
                + "------------------------------------------------------------" + "\n"
                + "- Player_Two_Name: " + Player2Name + "\n"
                + "- Player_Two_Score: " + Player2Score + "\n"
                + "- Player_Two_Number_of_Dice_Rolls: " + Player2DiceRolls + "\n"
                + "------------------------------------------------------------" + "\n"
                + "- Amount_of_Rounds: " + Rounds + "\n"
                + "- Winner_By_Score: " + winner + "\n"
                + "------------------------------------------------------------" + "\n"
                + "¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯";

        System.out.println(inputText);
        System.out.println("\n");

        out.close();

        System.out.println("__________________________________________________________");
        System.out.println("----------------------------------------------------------");
        System.out.println("The Stats have been written to the file " + outputfileName);
        System.out.println("----------------------------------------------------------");
        System.out.println("¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯");
        System.out.println("\n");
    }//End of stats method
}//End of class.
