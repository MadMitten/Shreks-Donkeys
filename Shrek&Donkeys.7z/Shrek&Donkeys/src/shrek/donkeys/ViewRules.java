/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shrek.donkeys;

/**
 *
 * @author k00225361
 */
import java.io.*;

public class ViewRules {

    public void viewRules() throws Exception {
        File file = new File("C:\\Users\\jorda\\Desktop\\New folder\\Shrek&Donkeys\\src\\shrek\\donkeys\\RulesforShrekandDonkey.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;

        while ((st = br.readLine()) != null) {
            System.out.println(st);
        }
        System.out.println("\n");
    }

}
