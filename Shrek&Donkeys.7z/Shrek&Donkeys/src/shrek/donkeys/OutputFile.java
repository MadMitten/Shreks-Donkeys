/*
 * Is used in main menu to display Stats;
 */
package shrek.donkeys;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 *
 * @author jorda
 */
public class OutputFile {
    
    public void viewStats() throws Exception {
        File file = new File("C:\\Users\\jorda\\Desktop\\New folder\\Shrek&Donkeys\\Stats.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;

        while ((st = br.readLine()) != null) {
            System.out.println(st);
        }
        System.out.println("\n");
    }
}
