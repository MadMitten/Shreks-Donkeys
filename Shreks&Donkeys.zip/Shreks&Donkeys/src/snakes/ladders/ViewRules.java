/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakes.ladders;

/**
 *
 * @author k00225361
 */
import java.io.*;

public class ViewRules {

    public void viewRules() throws Exception {
        File file = new File("C:\\Users\\eomot\\OneDrive\\Desktop\\Snakes-Ladders-master\\Shreks&Donkeys\\src\\snakes\\ladders\\RulesforShrekandDonkey.txt");

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;

        while ((st = br.readLine()) != null) {
            System.out.println(st);
        }

        System.out.println("\n");
    }

}
